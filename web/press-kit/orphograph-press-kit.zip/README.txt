ORPHOGRAPH — PRESS KIT
Established 2026. An empirical notary.

This archive contains the institutional brand assets and the brand guide,
provided for editorial use by journalists, reviewers, and academic writers.

------------------------------------------------------------
CONTENTS
------------------------------------------------------------

  seal.png                       Institutional seal, 1254 by 1254 px,
                                 transparent background.
  seal-display.png               Display variant of the seal, 600 by 600
                                 px, transparent background.
  lockup.png                     Seal plus wordmark, 1736 by 906 px,
                                 transparent background.
  favicon.ico                    Multi-resolution favicon for legacy
                                 browser tabs.
  favicon-16.png                 16 by 16 px favicon.
  favicon-32.png                 32 by 32 px favicon.
  apple-touch-icon-180.png       180 by 180 px touch icon.
  og-image.png                   Open Graph social card.
  orphograph-brand-guide.txt     Plain-text brand guide.
  orphograph-brand-guide.html    Printable brand guide (open in a browser
                                 and Save as PDF for a print-ready file).

------------------------------------------------------------
BRAND PALETTE
------------------------------------------------------------

  Cream          #f7f1e3   surface, paper
  Ink            #14110d   primary type
  Confirm green  #3a6a4c   attestation, the receipt mark

A classical book-weight serif (EB Garamond is the reference) is used for
display and body type. Any equivalent serif at regular or medium weight
is an acceptable substitute. No third-party brand-font reference is used.

------------------------------------------------------------
A LIVE SAMPLE RECEIPT
------------------------------------------------------------

A real, publicly addressable receipt issued by the office:

  https://orphograph.com/r/7KViBg91CR8D4mTr

The receipt is verifiable against the public Bitcoin blockchain at any
time, using the MIT-licensed offline verifier kit at
https://orphograph.com/dist/orphograph-verify.zip.

------------------------------------------------------------
LICENCE
------------------------------------------------------------

Protocol source code is published under the MIT licence and is available
on the public source tree. The brand — name, seal, wordmark, lockup,
voice, written copy, and the visual system described in the brand guide
— is reserved. The brand is not part of the MIT-licensed code release.

------------------------------------------------------------
CONTACT
------------------------------------------------------------

Press correspondence:  hello@orphograph.com
Security disclosure:   security@orphograph.com
Press kit web page:    https://orphograph.com/press-kit.html

The office responds to press inquiries within a small number of business
days.
