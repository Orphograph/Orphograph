# orphograph-verify

Standalone verifier for [Orphograph](https://orphograph.com) receipts.

If Orphograph's domain disappears tomorrow, this directory is all you
need to prove that a file — or a whole folder — existed at a moment in
time. It re-derives the Merkle root of a folder, walks an inclusion
proof for a single file, and (optionally) invokes the OpenTimestamps
reference client to confirm that the Bitcoin-chain witness references
the same root.

Stdlib only. No `pip install`. No network calls (except for the
optional `ots verify` sub-check, which is performed by the OpenTimestamps
reference client when present, not by this script).

## Why this directory exists

Orphograph is a service that hashes files in your browser and anchors
those hashes to the Bitcoin blockchain via OpenTimestamps. The crypto
is open; the convenience is what is sold.

That convenience only matters if the underlying proof outlives the
company that issued it. This verifier is published as MIT so that:

1. The format is auditable. A receipt is `receipt.json` plus standard
   `.ots` proof files; a folder anchor adds a `manifest.json`.
2. It runs offline.
3. If the service is unavailable, the receipt still verifies.

## Layout

```
verify.py       — entry point with two subcommands (file / folder)
merkle.py       — vendored copy of server/merkle.py (RFC 6962, banner notes)
README.md       — this file
LICENSE         — MIT
examples/       — sample receipts and folders for smoke-testing
```

The vendored `merkle.py` carries a sha256 banner at the top so the
copy can be re-derived from the source of truth at any time.

## Usage

### Verify a single file via an inclusion proof

```
python3 verify.py file --file path/to/original.jpg \
                       --proof path/to/proof.json \
                       [--ots path/to/root.ots]
```

The proof JSON is the document returned by the Orphograph
`/api/inclusion_proof` endpoint (or any equivalent producer). It
carries the relative path, the expected root hex, the file's
SHA-256, and the list of sibling hashes that walk the leaf up to the
root.

The verifier re-hashes the local file, cross-checks against the
proof's recorded `file_sha256_hex` when present, and then walks the
proof bottom-up using the RFC 6962 algorithm defined in `merkle.py`.

### Verify a whole folder via its manifest

```
python3 verify.py folder --dir path/to/folder \
                         --manifest path/to/manifest.json \
                         [--ots path/to/root.ots] \
                         [--exclude GLOB ...]
```

The verifier walks the local directory through the same RFC 6962
algorithm the server uses, computes the root, and compares it to the
`root_hex` recorded in the manifest. A mismatch is a `FAIL`; an
exact match is an `OK`. The comparison is strict: the recomputed root
(lowercase by construction) must equal the manifest's `root_hex`
byte-for-byte — a manifest edited to uppercase does not verify.

If the folder was anchored with custom excludes, pass the SAME
repeatable `--exclude GLOB` flags here. Supplying any `--exclude`
replaces the default deny-list rather than extending it (identical
semantics to the Orphograph SDK CLI); with different excludes the
recomputed root cannot match the manifest.

You usually do not need the flags: manifests produced by the office or the
Python SDK carry a `scope` block that records the excludes the anchor used,
and `verify.py folder` walks with it (printing the patterns, and a `[WARN]`
if the block's self-checksum no longer matches — the root comparison still
decides). The recorded scope is authoritative (VERIFIER_SPEC §4.2, the same
rule the Python SDK follows): `--exclude` flags apply to manifests without
a scope block and are ignored with a warning otherwise, unless you pass
`--ignore-manifest-scope` to say you mean it. Manifests from producers that
do not yet write a scope block (e.g. the Node SDK) fall back to the flags or
the default deny-list.

### Optional OpenTimestamps sub-check

When `--ots` is supplied, the verifier first checks, offline, that the
`.ots` file's embedded digest is the `root_hex` it just reproduced
(otherwise the state is `UNBOUND` — the proof is about a different
hash). It then runs `ots verify -d <root_hex> <file.ots>` via subprocess
(list-form, never via a shell) and classifies the client's exit code and
wording into `VERIFIED` / `PENDING` / `FAILED` / `UNAVAILABLE` /
`INDETERMINATE`. Only `VERIFIED` is a pass. The client's output is never
searched for the hash as evidence of anything.

Install the OpenTimestamps reference client when needed:

```
pip install opentimestamps-client
```

If the binary is not on `PATH`, the verifier reports the absence and
returns exit code 4 — the core Merkle check is unaffected.

### Check any OpenTimestamps proof, not only ours

`ots` checks a `.ots` proof made by any tool or service against the original
file or its SHA-256. Nothing in it is specific to Orphograph:

```
python3 verify.py ots --file contract.pdf --ots contract.pdf.ots
python3 verify.py ots --sha256 <64 hex> --ots proof.ots
```

The binding is checked offline first: the header, the format version, and
that the proof commits to the file's **SHA-256** (a proof that commits to a
SHA-1, RIPEMD-160 or Keccak-256 of the file says so and is `UNBOUND`). Then
the OpenTimestamps client is asked, exactly as in the sub-check above. The
exit code is `0` only for `VERIFIED`, `4` for every other state.
`tests/vectors/foreign_ots/` in the source repository holds a proof made by
the OpenTimestamps project's own client, which the tests check.

### Checking without the internet

The OpenTimestamps client never asks a block explorer: it reads block
headers from **your own Bitcoin node** over RPC (a pruned node works; it
keeps every header). So a check can be fully offline, and no third party
learns which proof you checked. A node can even stay current with no
internet at all, from the free one-way broadcast of the Bitcoin chain by
satellite (Blockstream Satellite, which needs a satellite dish and receiver).
With no node, the result is `UNAVAILABLE`, which says nothing about the
proof; `ots info <file.ots>` still prints the attestation offline.

## Exit codes

- `0` — verification succeeded
- `2` — invalid arguments or missing input files
- `3` — file or folder did not reproduce the recorded root
- `4` — the OpenTimestamps chain step did not pass. The line `[OTS] <STATE>:` on
  stdout says which: `FAILED` (the client rejected the proof) · `PENDING` (not yet
  on Bitcoin) · `UNAVAILABLE` (the check could not run — no `ots` binary or no
  Bitcoin node) · `UNBOUND` (the `.ots` commits to a different hash) ·
  `INDETERMINATE`. Only `FAILED` means the proof is bad; the others mean the
  chain step rendered no verdict. The Merkle/file result is unaffected either way.

## Measured performance (one data point, not a guarantee)

Folder mode over 10,000 files in 50 directories (~15 MB of random bytes):
anchor-side tree build 0.85 s, `verify.py folder` 0.87 s wall, Python 3.11 on
an Apple-silicon laptop, 2026-08-22. Hashing is the cost; it scales with total
bytes, not file count. Re-measure on your machine with
`python3 tools/bench_verify_folder.py --files 10000 --dirs 50` from a repo
checkout (the script prints both numbers).

## License

MIT. See `LICENSE`. Copyright (c) 2026 the Orphograph contributors.
